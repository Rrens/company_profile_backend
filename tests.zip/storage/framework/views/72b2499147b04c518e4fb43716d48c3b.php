<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Restopia - <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('admin/css/main/app.css')); ?>" />
    
    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/logo/favicon.ico')); ?>" type="image/x-icon" />
    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/logo/favicon.png')); ?>" type="image/png" />

    <link rel="stylesheet" href="<?php echo e(asset('admin/css/shared/iconly.css')); ?>" />

    <style>
        /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>

    <?php echo $__env->yieldPushContent('head'); ?>

</head>

<body>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="app">
        <?php echo $__env->make('admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>

            <?php echo $__env->yieldContent('container'); ?>

            <?php echo $__env->make('admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('admin/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/app.js')); ?>"></script>



</body>

</html>
<?php /**PATH D:\belajar\project\company-backend\resources\views/admin/components/master.blade.php ENDPATH**/ ?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>BIKO - <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="preload" href="<?php echo e(asset('assets/css/style.css')); ?>" as="style">
    <link rel="preload" href="<?php echo e(asset('assets/script/app.js')); ?>" as="script">
    <link rel="preload" href="<?php echo e(asset('assets/script/app.js')); ?>" as="script">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <meta name="robots" content="index,follow">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/img/icon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/icon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/icon/favicon-16x316.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/site.webmanifest')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('assets/safari-pinned-tab.svg')); ?>" color="#333333">
    <meta name="msapplication-TileColor" content="#333333">
    <meta name="theme-color" content="#ffffff">

    <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body class="loading full_border <?php echo e(!empty($page) ? $page : ''); ?>">
    <?php echo $__env->make('components.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('container'); ?>

    <script src="<?php echo e(asset('assets/script/load.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/script/app.js')); ?>" defer></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\belajar\project\company-backend\resources\views/components/master.blade.php ENDPATH**/ ?>
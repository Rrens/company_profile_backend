
<div id="header_close" class="close_btn on_header"><span></span> <span></span></div>
<div class="menu_wrapper boxhover">
    <div>
        <ul>
            <li><a href="<?php echo e(route('brand.index')); ?>">BRANDS</a>
            </li>
            <li><a href="<?php echo e(route('event.index')); ?>">EVENTS & PROGRAMS</a>
            </li>
            <li><a href="<?php echo e(route('career.index')); ?>">CAREERS</a>
            </li>
            <li><a href="<?php echo e(route('contact.index')); ?>">CONTACT</a>
            </li>
        </ul>
        <section class="brand_sliders white">
            <div class="bs_collapse_head">OUTLETS <img src="<?php echo e(asset('assets/img/icon/arrow_down.svg')); ?>"></div>
            <div class="brand_slider_wrapper dragscroll">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="each_brand_slider" href="<?php echo e(route('brand.select', $item->name)); ?>"><?php echo e($item->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="__nav prev"><svg class="nav_arrow" width="14px" height="9px" viewBox="0 0 14 9"
                    version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g transform="translate(-337.000000, -21.000000)" stroke="#000000" stroke-width="2"
                        fill="transparent">
                        <polyline points="338 22 344.070504 28.3529412 350 22.1475688"></polyline>
                    </g>
                </svg></div>
            <div class="__nav next"><svg class="nav_arrow" width="14px" height="9px" viewBox="0 0 14 9"
                    version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g transform="translate(-337.000000, -21.000000)" stroke="#000000" stroke-width="2"
                        fill="transparent">
                        <polyline points="338 22 344.070504 28.3529412 350 22.1475688"></polyline>
                    </g>
                </svg></div>
        </section>
    </div>
</div>
<?php /**PATH D:\belajar\project\company-backend\resources\views/components/loader.blade.php ENDPATH**/ ?>
<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header position-relative">
            <div class="d-flex justify-content-between align-items-center">
                <div class="logo">
                    <a href=""><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="Logo" width="100px"
                            srcset="" /></a>
                </div>
                <div class="theme-toggle d-flex gap-2 align-items-center mt-2">
                    <div class="form-check form-switch fs-6">
                        <input class="form-check-i nput me-0" type="checkbox" id="toggle-dark" hidden />
                        
                    </div>
                </div>
                <div class="sidebar-toggler x">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-title">ADMIN</li>
                <?php if(auth()->user()->role == 'superadmin'): ?>
                    <li class="sidebar-item <?php echo e($active == 'admin' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.member.index')); ?>" class="sidebar-link">
                            <i class="bi bi-people"></i>
                            <span>Members</span>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="sidebar-item <?php echo e($active == 'brands' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.brand.index')); ?>" class="sidebar-link">
                        <i class="bi bi-house-fill"></i>
                        <span>Brands</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e($active == 'galery' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.galeries.index')); ?>" class="sidebar-link">
                        <i class="bi bi-image-fill"></i>
                        <span>Galeries</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e($active == 'header' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.header.index')); ?>" class="sidebar-link">
                        <i class="bi bi-image"></i>
                        <span>Header</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e($active == 'event' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.event.index')); ?>" class="sidebar-link">
                        <i class="bi bi-calendar-event-fill"></i>
                        <span>Event</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e($active == 'career' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.career.index')); ?>" class="sidebar-link">
                        <i class="bi bi-people-fill"></i>
                        <span>Career</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e($active == 'menu' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.menu.index')); ?>" class="sidebar-link">
                        <i class="bi bi-menu-app-fill"></i>
                        <span>Menu</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e($active == 'happening' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.happening.index')); ?>" class="sidebar-link">
                        <i class="bi bi-grid-fill"></i>
                        <span>Happening</span>
                    </a>
                </li>
                <li class="sidebar-item ">
                    <a href="<?php echo e(route('logout')); ?>" class="sidebar-link">
                        <i class="bi bi-door-open-fill"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\belajar\project\company-backend\resources\views/admin/components/sidebar.blade.php ENDPATH**/ ?>
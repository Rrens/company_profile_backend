<?php $__env->startSection('title', 'CAREER'); ?>

<?php $__env->startSection('container'); ?>
    <div class="sections_wrapper ">


        <section class="title_text header_padding">
            <div class="_wrapper title_style">SUPERB QUALITY BLOOD WANTED!</div>
        </section>
        <section class="container_career spaceBottom _grow">
            <div class="_wrapper">
                
                <div class="body_style_left">
                    We optimizing quality with a blend of tradition cooking. <br /><br /><strong>Focus</strong> on providing
                    an unforgettable
                    enjoyment
                    of signature taste.
                </div>
                <div class="career_list">
                    <ul>
                        <?php if(!empty($data[0])): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('career.select_career', $item->position)); ?>"><?php echo e($item->position); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>Data Not Found</p>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </section>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\project\company-backend\resources\views/page/career/index.blade.php ENDPATH**/ ?>
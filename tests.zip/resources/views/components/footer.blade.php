<footer class="">
    <div class="footer_wrapper">
        <form class="footer_subscribe">
            <div class="fs_respond hide"></div>
            <div class="fs_label">BE IN OUR INNER CIRCLE!</div>
            <input class="fs_input" id="subs_email" placeholder="enter your e-mail address" type="email">
            <input id="footerSubmit" class="fs_submit" type="submit" value="I WANT IN!" d-value="I WANT IN!"
                m-value="SUBSCRIBE">
        </form>`
        <div class="footer_copyright">2022 © 1010 GROUP</div>
    </div>
</footer>

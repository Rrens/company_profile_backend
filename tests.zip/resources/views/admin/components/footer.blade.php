<footer>
    <div class="footer clearfix mb-0 text-muted mt-4">
        <div class="float-start">
            <p>&copy; Copyright 2023 1010 GROUP. All Rights Reserved.</p>
        </div>
        <div class="float-end">
            <p>
                Hand Crafted & Made Withs
                <span class="text-danger"><i class="bi bi-heart"></i></span>
            </p>
        </div>
    </div>
</footer>

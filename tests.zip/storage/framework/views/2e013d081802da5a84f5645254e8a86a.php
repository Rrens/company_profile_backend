<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('container'); ?>
    <div class="sections_wrapper ">
        <section class="home_slider slider_section">
            <div class="scrolldown">
            </div>
            <div class="slider_wrapper">
                <div class="slider_each " color="white">
                    <img class="slider_img" src="<?php echo e(asset('assets/img/home_image.jpg')); ?>">
                    <img class="slider_img mobile" src="<?php echo e(asset('assets/img/home_image.jpg')); ?>">
                </div>
            </div>
            <div class="slider_navs"></div>
        </section>

        <section class="all_brands_module top_border">
            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="all_brands_module_each white" href="<?php echo e(route('brand.select', $item->name)); ?>">
                    <span class="hb_title"><?php echo e($item->name); ?></span>
                    <img class="hb_logo"
                        src="<?php echo e(empty($image->where('id_brand', $item->id)->first()['image']) ? '-' : asset('storage/uploads/image/' . $image->where('id_brand', $item->id)->first()['image'])); ?>">
                    <img class="hb_img_bg"
                        src="<?php echo e(empty($thumbnail->where('id_brand', $item->id)->first()['image']) ? '-' : asset('storage/uploads/thumbnail/' . $thumbnail->where('id_brand', $item->id)->first()['image'])); ?>">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\project\company-backend\resources\views/page/home/index.blade.php ENDPATH**/ ?>
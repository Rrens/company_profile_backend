<?php $__env->startSection('title', 'EVENT'); ?>

<?php $__env->startSection('container'); ?>
    <div class="popup__container dragscroll"><span class="popup__mobile-back"><span class="back_btn popup__close"><svg
                    class="backarrow" width="14px" height="9px" viewBox="0 0 14 9" version="1.1"
                    xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g transform="translate(-337.000000, -21.000000)" stroke="#000000" stroke-width="2" fill="transparent">
                        <polyline points="338 22 344.070504 28.3529412 350 22.1475688"></polyline>
                    </g>
                </svg> <span>BACK</span></span></span>
        <div class="popup__image"><img src=""></div>
        <div class="popup__text">
            <div class="popup__contentwrapper">
                <p>THIS ONLINE SHOP IS FOR ILLUSTRATIVE PURPOSE ONLY. TO ORDER, CLICK THIS <a href="#">WHATSAPP
                        LINK</a> TO GET CONNECTED TO OUR CREW.</p>
            </div><span class="popup__text_btn popup__close"><span>CLOSE</span></span>
        </div>
        <div class="popup__bg"></div>
    </div>



    <div class="sections_wrapper ">
        <section class="title_text header_padding bottom_border">
            <div class="_wrapper title_style">THE HAPPENINGS YOU DON'T WANNA MISS</div>
        </section>
        <div class="___wrapper">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="container_event_title getposition">
                    <a href="<?php echo e(route('brand.select', $item->brand[0]->name)); ?>"
                        class="brand_event_title"><?php echo e($item->brand[0]->name); ?></a>
                </section>
                <section class="container_event">
                    <div class="events_promotion_title">
                        <span class="events_title">SPECIAL EVENTS</span>
                        <span class="promotion_title">WEEKLY PROGRAMS</span>
                    </div>
                    <div class="ep_content">
                        <div class="events_text">
                            <?php if($item->category == 'SPECIAL EVENT'): ?>
                                <span class="inner_text_all">
                                    <p><?php echo e(date('l, M d Y', strtotime($item->date))); ?>, <?php echo e($item->open_time . '.00'); ?> to
                                        <?php echo e($item->close_time . '.00'); ?></p>
                                    <p class="popup" data-popuptype="image"
                                        data-imgsrc="<?php echo e(empty($item->image) ? '-' : asset('storage/uploads/event/' . $item->image)); ?>">
                                        <?php echo e($item->name); ?></p>
                                </span>
                            <?php else: ?>
                                <span class="inner_text_all">
                                    <p> NO PROGRAMS</p>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="promotion_text">
                            <?php if($item->category == 'WEEKLY PROGRAMS'): ?>
                                <span class="inner_text_all">
                                    <p><?php echo e(date('l, M d Y', strtotime($item->date))); ?>, <?php echo e($item->open_time . '.00'); ?> to
                                        <?php echo e($item->close_time . '.00'); ?></p>
                                    <p class="popup" data-popuptype="image"
                                        data-imgsrc="<?php echo e(empty($item->image) ? '-' : asset('storage/uploads/event/' . $item->image)); ?>">
                                        <?php echo e($item->name); ?></p>
                                </span>
                            <?php else: ?>
                                <span class="inner_text_all">
                                    <p> NO PROGRAMS</p>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\project\company-backend\resources\views/page/event/index.blade.php ENDPATH**/ ?>
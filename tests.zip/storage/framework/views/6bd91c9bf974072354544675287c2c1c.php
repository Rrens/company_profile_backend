<?php $__env->startSection('title', 'CAREER'); ?>

<?php $__env->startSection('container'); ?>
    <div class="sections_wrapper ">


        <section class="title_text subheader_padding">
            <div class="_wrapper title_style"><?php echo e($data->position); ?></div>
        </section>
        <section class="container_career">
            <div class="_wrapper">
                <div class="body_style_left">Are you a social butterfly wondering if that could pay your bills?</div>
                <div class="career_sidetext spaceBottom _grow default__style">
                    <div class="career_spec">
                        <span>SPECIFICATIONS</span>
                        <p><br />Make sure that you:</p>
                        <ul>
                            <?php echo $data->description; ?>

                        </ul>
                        <span class="career_apply">To apply, please send your CV to <a href="#">hrd@biko-group.com</a>
                            or click the button below.</span>
                    </div><a href="mailto:" class="btn_apply">LET ME IN</a>
                </div>
            </div>
        </section>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\project\company-backend\resources\views/page/career/detail.blade.php ENDPATH**/ ?>